import React from "react";
import ProductItem from "./ProductItem";

function ProductsList({ list, addCart }) {
  const productItems = list.map((product) => (
    <ProductItem key={product.title} product={product} addCart={addCart} />
  ));

  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Products</h2>
      <ul>{productItems}</ul>
    </>
  );
}

export default ProductsList;
