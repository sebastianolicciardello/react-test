import React from "react";
import CartItem from "./CartItem";
import CartEmpty from "./CartEmpty";

function Cart({ cartItems, modifyQuantity }) {
  const cartList = cartItems
    .filter((item) => item.quantity > 0)
    .map((item) => (
      <CartItem key={item.id} item={item} modifyQuantity={modifyQuantity} />
    ));

  if (cartItems.length === 0) {
    return (
      <>
        <h2 className="text-2xl font-bold mb-4">Cart</h2>
        <CartEmpty />
      </>
    );
  }

  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Cart</h2>
      <ul>{cartList}</ul>
    </>
  );
}

export default Cart;
