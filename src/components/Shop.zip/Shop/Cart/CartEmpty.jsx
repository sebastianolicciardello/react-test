import React from "react";

function CartEmpty() {
  return (
    <>
      <h3 className="text-l font-bold mb-4">Cart is empty</h3>
    </>
  );
}

export default CartEmpty;
